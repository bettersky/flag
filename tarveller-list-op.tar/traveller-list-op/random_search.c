#include "main.h"
#include <time.h>
extern struct HEADER *list_header;

extern uint64_t search_size;  
extern uint64_t total;  
extern int thread_total;

extern int search_thread_total;

int search_with_lock(uint64_t searching_key){
	struct KNODE* insert_point=search_insert_point(list_header->curr_max, list_header->key_head, searching_key,0);
			
	if(searching_key==insert_point->key){
				//printf("YYYYYYYYYYYYYY, equal\n");
	}
	else if(insert_point->next[0]==NULL || searching_key<insert_point->next[0]->key){//then must be >0 and less than the next key, so we insert
				//new_key->next[0]=insert_point->next[0];
				//insert_point->next[0]=new_key;				
				//pthread_mutex_unlock(  &(insert_point->mutex) );
	}
	else if(searching_key> insert_point->next[0]->key){
				printf("%d:insert, OOOOOOOOOOOOOO, error. insert_point->next[0]->key=%d, key=%d\n",pthread_self(),insert_point->next[0]->key,searching_key);
				exit(9);
	}	
	return 1;
}
int random_search(){
//printf("%d:search begin,total=%d,  search_thread_total=%d, total/search_thread_total=%d\n",pthread_self(),total,search_thread_total,total/search_thread_total);
	srand( (unsigned)time( NULL ) );
	
	int i;
	int xx=total/search_thread_total;
	for(i=0;i<xx;i++){		
		uint64_t searching_key=rand();
		//pure_search(list_header->curr_max, list_header->key_head, searching_key,0);
		pure_travel_not_recur(searching_key);
		//search_with_lock(searching_key);
		//search_size++;
		//printf("search_size=%d\n",search_size);
	}
	//printf("end\n");

}
