#include "main.h"
extern struct HEADER *list_header;

int globle;
int thread_sleep=0;//100000;

uint64_t size=0;
uint64_t search_size=0;
uint64_t total=0;
int thread_total=1;
void print_tail2();
void print_list(struct KNODE *list);

int add_flag=0;

int search_thread_total=0;
int equal_counter=0;

int built_info[10]={0};
int test(){

	list_header=(struct HEADER *)malloc(sizeof(struct HEADER));
	memset(list_header , 0, sizeof(struct HEADER));
	list_header->key_head=(struct KNODE*)malloc(sizeof(struct KNODE));
	memset(list_header->key_head,0 , sizeof(struct KNODE));
	//pthread_mutex_init(&(list_header->key_head->mutex),NULL);
	
	pthread_mutex_init(&(list_header->insert_mutex),NULL);
	int i;
	for(i=0;i<STATION_LEVEL_MAX;i++){
		pthread_mutex_init(&(list_header->station_builder_mutex[i]),NULL);
	}
	
	thread_total=4;
	total=22222;
	
	printf("Input thread_total:\n");
	printf("Input bench size:\n");
	
	
	scanf("%d",&thread_total);
	scanf("%d",&total);
	
	//printf("%d threads\n",thread_total);
	
	printf("%d KV\n",total);
	
	
	create_thread(0);
	//random_write();
	print_tail2();
	/*
	while(1){
		search_size=0;
		equal_counter=0;
		printf("Insert %llu items, now input search_thread_num and search size:\n", size);
		scanf("%d", &search_thread_total);
		scanf("%d", &total);
		printf("search_size=%d, total=%d,  Begin search...\n",search_size,total);
		create_search_thread(0);
		printf("equal_counter=%d, percent=%f\%\n",equal_counter,(double)equal_counter/total);
	}
	
	*/
	
	for(i=0;i<10;i++){
		printf("built_info[%d]=%d\n",i,built_info[i]);
	}
	
}


void print_tail2(){
	int i;
	for(i=0;i<STATION_LEVEL_MAX;i++){
		if(list_header->key_head->next[i]!=NULL){
			int j=0;
			struct KNODE *temp= list_header->key_head->next[i];
			//printf("\n");
			while(temp!=NULL){
				j++;
				
				//if(i>6){
					//printf("%p->",temp);
					//printf("in tail2, j is bigger than total, i=%d, exit\n", i);
					//exit(3);
				//}
				temp=temp->next[i];
			}
			//printf("\n");
			printf("flags in level %d:   %d\n",i,j);
		}
	}
	
	//printf("0 node is %p\n",list_header->key_head->next[0] );
	

}

