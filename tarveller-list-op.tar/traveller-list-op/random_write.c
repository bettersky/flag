#include "main.h"
#include <time.h>

extern uint64_t size;  
extern uint64_t total;  

int random_write(){

	srand( (unsigned)time( NULL ) );
	
	for(;size<total;){		
		insert(rand());
		size++;
	}
	printf("end\n");

}
