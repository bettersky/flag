#include "main.h"

extern struct HEADER *list_header;

extern uint64_t size;  
extern uint64_t total; 

int insert(uint64_t key){

	struct KNODE *new_key=(struct KNODE *)malloc(sizeof(struct KNODE));
	memset(new_key,0, sizeof(struct KNODE));
	new_key->key=key;
	
	uint64_t searching_key=key;
					
	struct KNODE* insert_point=search_insert_point(list_header->curr_max, list_header->key_head, searching_key,0);
			
	if(key==insert_point->key){
				//printf("YYYYYYYYYYYYYY, equal\n");
	}
	else if(1){//insert_point->next[0]==NULL || key<insert_point->next[0]->key .then must be >0 and less than the next key, so we insert
				//printf("1111\n");
				pthread_mutex_lock(  &(list_header->insert_mutex) );
				struct KNODE *advancer_insert=insert_point;
				
				while(insert_point->next[0]!=NULL){
					if(key < advancer_insert->next[0]->key){
						break;
					}
					advancer_insert=advancer_insert->next[0];
				}
				//printf("999\n");
				assert(advancer_insert!=NULL);
				new_key->next[0]=advancer_insert->next[0];
				advancer_insert->next[0]=new_key;		
				
				pthread_mutex_unlock(  &(list_header->insert_mutex) );
	}
	else if(key> insert_point->next[0]->key){
				printf("%d:insert, OOOOOOOOOOOOOO, error. insert_point->next[0]->key=%d, key=%d\n",pthread_self(),insert_point->next[0]->key,key);
				
				
				//exit(9);
	}	
	return 1;
	
}
