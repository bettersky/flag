#include "main.h"
extern struct HEADER *list_header;

extern int equal_counter;

struct KNODE * pure_travel_not_recur(uint64_t searching_key){

	int curr_station_level;
	struct KNODE* searching_point=list_header->key_head;
	 struct KNODE *bigger_station_point=list_header->key_head;
	
	for(curr_station_level=list_header->curr_max;curr_station_level>=0;curr_station_level--){
		
		int continue_flag=0;
		while(searching_point->next[curr_station_level]!=NULL){
			if(searching_key > searching_point->next[curr_station_level]->key){					
				searching_point=searching_point->next[curr_station_level];				
				continue;
			}	
			else if(searching_key < searching_point->next[curr_station_level]->key){//find insert point
				if(curr_station_level==0 ){
	//printf("xxxxxxx thread:%d, curr_station_level=%d\n",pthread_self(),curr_station_level);	

					return searching_point;
				}
				else{
					//return pure_search(curr_station_level-1, searching_point, searching_key,deep+1);
					//continue_flag=1;//go on the lower layer
					
					break;
				}
			}
			else if(searching_key==searching_point->next[curr_station_level]->key){
				equal_counter++;
				return searching_point->next[curr_station_level];
			}
		
		
		}
		
	
	}


}